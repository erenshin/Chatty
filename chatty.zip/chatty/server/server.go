package server

import (
	"../chatty"
	"encoding/gob"

	"fmt"
	"net"
)

var users = make(map[string]int)
var uid = 0

func handleConnection(conn net.Conn) {
    // chatConn := chatty.ChatConn{Dec: gob.NewDecoder(conn), Conn: conn}
	// msg, _ := chatty.RecvMsg(chatConn)

	dec := gob.NewDecoder(conn)
	var msg chatty.ChattyMsg
	dec.Decode(&msg)

	fmt.Printf("{Username: \"%v\", Body: \"%v\", Action: %v}\n", msg.Username, msg.Body, msg.Action)

	switch msg.Action {
	case chatty.CONNECT:
		if _, ok := users[msg.Username]; ok {
			conn.Close()
			break
		}
		users[msg.Username] = uid
		fmt.Printf("User %v connected with uid %v\n", msg.Username, uid)
		uid++
	case chatty.DISCONNECT:
		delete(users, msg.Username)
		fmt.Printf("User %v disconnected\n", msg.Username)
		conn.Close()
	case chatty.LIST:
		var users string
		for user := range users { 
			users += fmt.Sprintf(" - %v\n", user)
		}
		enc := gob.NewEncoder(conn)
		msgSend := chatty.ChattyMsg{Username: "List of users:\n", Body: users, Action: chatty.MSG}
		enc.Encode(&msgSend)
	case chatty.MSG:
		for user := range users { 
			if (user != msg.Username) {
				enc := gob.NewEncoder(conn)
				msgSend := chatty.ChattyMsg{Username: msg.Username, Body: msg.Body, Action: chatty.MSG}
				enc.Encode(&msgSend)
			}
		}
	}
}

func Start() {
	listen, port, err := chatty.OpenListener()
	fmt.Printf("Listening on port %v\n", port)

	if err != nil {
		fmt.Println(err)
		return
	}

	for {
		conn, err := listen.Accept() // this blocks until connection or error
		if err != nil {
			fmt.Println(err)
			continue
		}
		go handleConnection(conn)
	}
}
