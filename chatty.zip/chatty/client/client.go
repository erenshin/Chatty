package client

import (
	"../chatty"

	"fmt"
	"bufio"
	"os"
)

func Start(user string, serverPort string, serverAddr string) {
	// Connect to chat server
	chatConn, err := chatty.ServerConnect(user, serverAddr, serverPort)
	if err != nil {
		fmt.Printf("unable to connect to server: %v\n", err)
		return
	}

	fmt.Printf("Connected to server at %v\n", serverAddr)
	for {
		reader := bufio.NewReader(os.Stdin)
		text, _ := reader.ReadString('\n')

		msg := chatty.ChattyMsg{Username: user, Body: text, Action: chatty.MSG}
		chatConn.Enc.Encode(&msg)
    }
}
