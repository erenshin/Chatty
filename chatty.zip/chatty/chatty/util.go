package chatty

import (
	"encoding/gob"
	"fmt"
	"net"
)

type ChatConn struct {
	Enc  *gob.Encoder
	Dec  *gob.Decoder
	Conn net.Conn
}

// Connects a chat client to a chat server
func ServerConnect(username string, serverAddr string, serverPort string) (ChatConn, error) {
	chatConn := ChatConn{}
	fmt.Printf("Connecting to %s:%s\n", serverAddr, serverPort)
	conn, err := net.Dial("tcp", serverAddr + ":" + serverPort)
	if err != nil {
		return chatConn, err
	}
	chatConn.Conn = conn
	chatConn.Enc = gob.NewEncoder(conn)
	chatConn.Dec = gob.NewDecoder(conn)

	msg := ChattyMsg{Username: username, Action: CONNECT}
	chatConn.Enc.Encode(&msg)

	return chatConn, nil
}

func SendMsg(chatConn ChatConn, msg ChattyMsg) {
	chatConn.Enc.Encode(&msg)
}

// Receive next ChattyMsg from a ChatConn (blocks)
func RecvMsg(chatConn ChatConn) (ChattyMsg, error) {
	var chatMsg ChattyMsg
	err := chatConn.Dec.Decode(&chatMsg)
	return chatMsg, err
}

func (msg ChattyMsg) String() string {
	return fmt.Sprintf("{Username: \"%v\", Body: \"%v\", Action: %v}", msg.Username, msg.Body, msg.Action)
}

func (purpose Purpose) String() string {
	switch purpose {
	case CONNECT:
		return "CONNECT"
	case MSG:
		return "MSG"
	case LIST:
		return "LIST"
	case ERROR:
		return "ERROR"
	case DISCONNECT:
		return "DISCONNECT"
	default:
		return "Unknown Purpose!"
	}
}
